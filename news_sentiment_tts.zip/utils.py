import requests
from bs4 import BeautifulSoup
from newspaper import Article
from vaderSentiment.vaderSentiment import SentimentIntensityAnalyzer
from gtts import gTTS
import os

analyzer = SentimentIntensityAnalyzer()

def fetch_news(company):
    search_url = f'https://news.google.com/search?q={company}&hl=en-US&gl=US&ceid=US:en'
    headers = {'User-Agent': 'Mozilla/5.0'}
    response = requests.get(search_url, headers=headers)
    soup = BeautifulSoup(response.text, 'html.parser')
    links = [a['href'] for a in soup.select('a[href]') if '/articles/' in a['href']][:10]
    return ["https://news.google.com" + link for link in links]

def summarize_and_analyze(url):
    article = Article(url)
    article.download()
    article.parse()
    article.nlp()
    
    sentiment_score = analyzer.polarity_scores(article.summary)['compound']
    sentiment = 'Positive' if sentiment_score > 0.05 else 'Negative' if sentiment_score < -0.05 else 'Neutral'
    
    return {"Title": article.title, "Summary": article.summary, "Sentiment": sentiment}

def comparative_analysis(results):
    sentiment_counts = {"Positive": 0, "Negative": 0, "Neutral": 0}
    for result in results:
        sentiment_counts[result['Sentiment']] += 1
    return sentiment_counts

def generate_tts(text, lang='hi'):
    tts = gTTS(text=text, lang=lang)
    tts.save("output.mp3")
    return "output.mp3"
