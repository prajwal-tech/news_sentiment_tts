import requests
import streamlit as st

st.title("📰 News Sentiment & Hindi TTS App")

company = st.text_input("Enter Company Name:")
if st.button("Analyze"):
    response = requests.post("http://127.0.0.1:8000/analyze", json={"company": company})
    if response.status_code == 200:
        data = response.json()
        
        # Display Sentiment Analysis
        st.subheader("📊 Sentiment Analysis")
        st.json(data["results"])
        
        # Display Comparative Analysis
        st.subheader("🔍 Comparative Analysis")
        st.json(data["comparative_analysis"])
        
        # Play Hindi Text-to-Speech
        st.subheader("🔊 Hindi Audio Summary")
        st.audio(data["audio"])
    else:
        st.error("Error fetching data. Please try again.")
