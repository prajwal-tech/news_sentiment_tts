from fastapi import FastAPI
from pydantic import BaseModel
from fastapi.middleware.cors import CORSMiddleware
from utils import fetch_news, summarize_and_analyze, comparative_analysis, generate_tts

app = FastAPI()

# Enable CORS for frontend-backend communication
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

class CompanyRequest(BaseModel):
    company: str

@app.post("/analyze")
def analyze_news(data: CompanyRequest):
    urls = fetch_news(data.company)
    results = [summarize_and_analyze(url) for url in urls]
    comparative_results = comparative_analysis(results)
    
    sentiment_summary = "\n".join([f"{r['Title']}: {r['Sentiment']}" for r in results])
    tts_file = generate_tts(sentiment_summary)
    
    return {"results": results, "comparative_analysis": comparative_results, "audio": tts_file}
